# drowsy driver > 2025-06-18 2:14pm
https://universe.roboflow.com/mindwanderingyolo/drowsy-driver-kl6kx-nknrm-lfyds-macvf

Provided by a Roboflow user
License: CC BY 4.0

